package com.framgia.awesomedemo;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        setupFonts(this, new TextView[]{
            (TextView)findViewById(R.id.icon1),
            (TextView)findViewById(R.id.icon2),
            (TextView)findViewById(R.id.icon3),
            (TextView)findViewById(R.id.icon4),
            (TextView)findViewById(R.id.icon5),
            (TextView)findViewById(R.id.icon6),
            (TextView)findViewById(R.id.icon7)
        });
    }

    private void setupFonts(Context context, TextView[] textView) {
        Typeface font = Typeface.createFromAsset(context.getAssets(), "fonts/awesome.ttf");
        for (TextView tv : textView) {
            tv.setTypeface(font);
        }
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
