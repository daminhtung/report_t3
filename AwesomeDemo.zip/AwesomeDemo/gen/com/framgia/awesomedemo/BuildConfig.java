/** Automatically generated file. DO NOT MODIFY */
package com.framgia.awesomedemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}